## v8.0.7

- Fix sepolicy rule migration when upgrading

## v8.0.6

- Minor UI changes
- Update internal scripts
